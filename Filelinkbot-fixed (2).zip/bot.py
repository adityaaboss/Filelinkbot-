import asyncio
from pyrogram import Client

api_id = 123456  # replace with your API ID
api_hash = "your_api_hash"
bot_token = "your_bot_token"

app = Client("filelinkbot", api_id=api_id, api_hash=api_hash, bot_token=bot_token)

@app.on_message()
async def start(client, message):
    await message.reply("Hello, I'm alive!")

app.run()